UML-Editor - The UML/INTERLIS Editor

License
The UML-Editor is licensed under the LGPL (Lesser GNU Public License).

System Configuration
In order to execute the UML Editor, the JAVA run-time environment (JRE) version 1.6 or a more recent version must be installed on your system.
A free version of the JAVA run time environment (JRE) is available at the website http://www.java.com/.

Installation
In order to install the UML Editor, extract the ZIP file into a new directory.

How to run it?
To start the UML Editor, enter the following command at the commandline prompt

java -jar umleditor.jar [options]
java -Duser.language=FR -jar umleditor.jar

Comments/Suggestions
Please send comments to ce@eisenhutinformatik.ch.

