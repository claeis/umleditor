UML-Editor - Der UML-INTERLIS-Editor

Lizenz
Der UML-Editor ist lizensiert unter der LGPL (Lesser GNU Public License).

System Anforderungen
Um die aktuelle Version des UML-Editors auszuf�hren, muss die JAVA-Laufzeitumgebung (JRE) Version 1.6 oder neuer auf Ihrem System installiert sein.
Die JAVA-Laufzeitumgebung (JRE) k�nnen Sie auf der Website http://www.java.com/ gratis beziehen.

Installation
Um den UML-Editor zu installieren, entpacken Sie die ZIP-Datei in ein neues Verzeichnis.

Ausf�hren
Um den UML-Editor auszuf�hren, geben Sie auf der Kommandozeile folgendes Kommando ein

java -jar umleditor.jar [options]
java -Duser.language=FR -jar umleditor.jar

Kommentare/Anregungen
Bitte senden Sie Kommentare an ce@eisenhutinformatik.ch.
